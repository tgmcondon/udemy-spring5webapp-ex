package eclipse.group01aa.a02spring5webappex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A02Spring5webappExApplication {

	public static void main(String[] args) {
		SpringApplication.run(A02Spring5webappExApplication.class, args);
	}

}
