package eclipse.group01aa.a02spring5webappex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A02Spring5webappExApplicationTests {

	@Test
	void contextLoads() {
	}

}
